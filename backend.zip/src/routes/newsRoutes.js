import express from 'express';
import {
    getNews,
    getNewsBySlug,
    toggleLike,
    adminGetNews,
    adminCreateNews,
    adminUpdateNews,
    adminDeleteNews,
} from '../controllers/newsController.js';
import { protect, adminOnly, optionalAuth } from '../middleware/authMiddleware.js';

const router = express.Router();

// Public
router.get('/', getNews);
router.get('/admin/all', protect, adminOnly, adminGetNews);
router.get('/:slug', optionalAuth, getNewsBySlug);
router.post('/:id/like', protect, toggleLike);

// Admin CRUD
router.post('/admin', protect, adminOnly, adminCreateNews);
router.put('/admin/:id', protect, adminOnly, adminUpdateNews);
router.delete('/admin/:id', protect, adminOnly, adminDeleteNews);

export default router;
